export default {
  'logout': 'Вы вышли из системы'
}
